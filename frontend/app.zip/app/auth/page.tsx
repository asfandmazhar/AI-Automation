"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import axios from "axios";
import toast from "react-hot-toast";
import Cookies from "js-cookie";

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: any) => void;
          renderButton: (element: HTMLElement, config: any) => void;
        };
      };
    };
  }
}

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const router = useRouter();
  const [errors, setErrors] = useState<{ email?: string; password?: string }>(
    {},
  );
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const googleBtnRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = () => {
      if (window.google && googleBtnRef.current) {
        window.google.accounts.id.initialize({
          client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
          callback: handleGoogleResponse,
        });
        window.google.accounts.id.renderButton(googleBtnRef.current, {
          type: "standard",
          theme: "outline",
          size: "large",
          width: "100%",
          text: "continue_with",
          shape: "pill",
          logo_alignment: "center",
        });
      }
    };
    document.head.appendChild(script);
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  async function handleGoogleResponse(response: any) {
    setGoogleLoading(true);
    try {
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/google`,
        { credential: response.credential },
      );
      if (res.data.success) {
        const cookieOptions = remember ? { expires: 7 } : {};
        Cookies.set("access_token", res.data.access_token, cookieOptions);
        toast.success("Signed in successfully!");
        const roleName = res.data.role?.name?.toLowerCase();
        if (roleName === "admin") {
          router.push("/admin");
        } else {
          router.push("/dashboard");
        }
      } else {
        toast.error(res.data.message || "Google sign in failed");
      }
    } catch (err: any) {
      toast.error(
        err?.response?.data?.message || "Google sign in failed",
      );
    } finally {
      setGoogleLoading(false);
    }
  }

  function validateEmail(value: string): string | undefined {
    if (!value.trim()) return "Email is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
      return "Enter a valid email address";
    return undefined;
  }

  function validatePassword(value: string): string | undefined {
    if (!value) return "Password is required";
    if (value.length < 6) return "Password must be at least 6 characters";
    return undefined;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const next: typeof errors = {};
    next.email = validateEmail(email);
    next.password = validatePassword(password);
    setErrors(next);
    if (next.email || next.password) return;

    setIsLoading(true);
    try {
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/signin`,
        { email: email.trim(), password },
      );
      if (res.data.success) {
        const cookieOptions = remember ? { expires: 7 } : {};
        Cookies.set("access_token", res.data.access_token, cookieOptions);

        toast.success("Signed in successfully!");

        const roleName = res.data.role?.name?.toLowerCase();
        if (roleName === "admin") {
          router.push("/admin");
        } else {
          router.push("/dashboard");
        }
      } else {
        toast.error(res.data.message || "Sign in failed");
      }
    } catch (err: any) {
      toast.error(
        err?.response?.data?.message || "Failed to connect to server",
      );
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[color:var(--background)] px-4 py-8">
      <Card className="w-full max-w-sm p-8 sm:p-10 shadow-md">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[color:var(--primary)] shadow-sm">
            <span className="text-xl font-bold text-[color:var(--primary-foreground)]">
              A
            </span>
          </div>
          <div className="mt-1 space-y-1">
            <h1 className="text-xl font-semibold tracking-tight">
              Welcome Back
            </h1>
            <p className="text-sm text-[color:var(--muted-foreground)]">
              Sign in to your account to continue
            </p>
          </div>
        </div>

        <form className="mt-8 space-y-5" onSubmit={handleSubmit}>
          <Input
            id="email"
            type="email"
            label="Email"
            placeholder="you@example.com"
            icon={<Mail className="h-4 w-4" />}
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (errors.email)
                setErrors((p) => ({
                  ...p,
                  email: validateEmail(e.target.value),
                }));
            }}
            onBlur={() =>
              setErrors((p) => ({ ...p, email: validateEmail(email) }))
            }
            error={errors.email}
          />

          <Input
            id="password"
            type={showPassword ? "text" : "password"}
            label="Password"
            placeholder="Enter your password"
            icon={<Lock className="h-4 w-4" />}
            suffix={
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="cursor-pointer text-[color:var(--muted-foreground)] hover:text-[color:var(--foreground)] transition-colors duration-200"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            }
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (errors.password)
                setErrors((p) => ({
                  ...p,
                  password: validatePassword(e.target.value),
                }));
            }}
            onBlur={() =>
              setErrors((p) => ({
                ...p,
                password: validatePassword(password),
              }))
            }
            error={errors.password}
          />

          <div className="flex items-center pt-1">
            <Checkbox
              id="remember"
              label="Remember me"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
          </div>

          <Button
            type="submit"
            size="lg"
            className="mt-2 w-full hover:cursor-pointer"
            isLoading={isLoading}
          >
            Sign In
          </Button>

          <div className="relative my-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[color:var(--border)]" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-[color:var(--card)] px-3 text-[color:var(--muted-foreground)]">
                or
              </span>
            </div>
          </div>

          <div className="flex justify-center">
            <div ref={googleBtnRef} className="absolute h-0 w-0 overflow-hidden opacity-0" />
            <button
              type="button"
              disabled={googleLoading}
              onClick={() => {
                const iframe = googleBtnRef.current?.querySelector("div[role='button']") as HTMLElement;
                if (iframe) iframe.click();
              }}
              className="flex h-11 w-full cursor-pointer items-center justify-center gap-2.5 rounded-xl border border-[color:var(--border)] bg-[color:var(--card)] text-sm font-medium text-[color:var(--foreground)] transition-colors hover:bg-[color:var(--muted)]"
            >
              {googleLoading ? (
                "Signing in..."
              ) : (
                <>
                  <svg viewBox="0 0 24 24" className="h-5 w-5" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  </svg>
                  Continue with Google
                </>
              )}
            </button>
          </div>
        </form>
      </Card>
    </div>
  );
}
